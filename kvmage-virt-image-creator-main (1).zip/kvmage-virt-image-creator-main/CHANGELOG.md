# Changelog

## [v0.1.0]
## Added
- Initial release of KVMage
- Support for install and customize modes
- YAML-based config loading
- CLI validation
- Add option to --uninstall